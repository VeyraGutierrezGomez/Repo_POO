import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

public class PlanificadorTuristico {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                // Establecer el look and feel de Nimbus para un aspecto más moderno
                for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (Exception e) {
                // Si Nimbus no está disponible, usar el default
            }

            // Configurar colores personalizados
            UIManager.put("nimbusBase", new Color(0, 102, 153)); // Azul oscuro
            UIManager.put("nimbusBlueGrey", new Color(169, 176, 190));
            UIManager.put("control", new Color(240, 245, 250));

            new PlanificadorTuristicoGUI().setVisible(true);
        });
    }
}

class PlanificadorTuristicoGUI extends JFrame {
    //Componentes
    private List<Destino> destinosDisponibles;
    private Map<String, List<Actividad>> actividadesPorDestino;
    private List<Viaje> viajesPlaneados;
    private JComboBox<Destino> cbDestinos;
    private JSpinner spinnerFechaIda;
    private JSpinner spinnerFechaRegreso;
    private JTextField tfNochesHospedaje;
    private JComboBox<String> cbTipoHospedaje;
    private JSpinner spNumPersonas;
    private JList<Actividad> listActividades;
    private DefaultListModel<Actividad> modeloActividades;
    private JButton btnAgregarActividad;
    private JButton btnPlanearViaje;
    private JButton btnNuevoViaje;
    private List<Actividad> actividadesSeleccionadasGlobal = new ArrayList<>();

    //Función para mostrar el panel principal con los datos inicializados y los paneles secundarios (formulario y botones)
    public PlanificadorTuristicoGUI() {
        super("Viajes por México - Planificador");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1050, 750);
        setLocationRelativeTo(null);
        inicializarDatos();
        initUI();
    }

    //Lista de destinos y sus respectivas actividades
    private void inicializarDatos() {
        destinosDisponibles = new ArrayList<>();
        destinosDisponibles.add(new Destino("Cancún, Quintana Roo", 2500.0));
        destinosDisponibles.add(new Destino("Puerto Vallarta, Jalisco", 2200.0));
        destinosDisponibles.add(new Destino("Los Cabos, Baja California Sur", 3000.0));
        destinosDisponibles.add(new Destino("Mazatlán, Sinaloa", 1800.0));
        destinosDisponibles.add(new Destino("Acapulco, Guerrero", 1200.0));
        destinosDisponibles.add(new Destino("Oaxaca, Oaxaca", 900.0));
        destinosDisponibles.add(new Destino("San Miguel de Allende, Guanajuato", 800.0));
        destinosDisponibles.add(new Destino("Guanajuato, Guanajuato", 850.0));
        destinosDisponibles.add(new Destino("Puebla, Puebla", 400.0));
        destinosDisponibles.add(new Destino("Monterrey, Nuevo León", 1500.0));
        destinosDisponibles.add(new Destino("Mérida, Yucatán", 1800.0));
        destinosDisponibles.add(new Destino("Tulum, Quintana Roo", 2600.0));

        actividadesPorDestino = new HashMap<>();
        actividadesPorDestino.put("Cancún, Quintana Roo", Arrays.asList(
                new Actividad("Avistamiento de ballenas", 1200.0),
                new Actividad("Buceo en arrecifes", 1500.0),
                new Actividad("Esnórquel en cenote", 400.0),
                new Actividad("Excursión a isla", 1000.0),
                new Actividad("Laguna bioluminiscente", 300.0),
                new Actividad("Nado con delfines", 1200.0),
                new Actividad("Zona arqueológica (entrada general)", 85.0)
        ));

        actividadesPorDestino.put("Puerto Vallarta, Jalisco", Arrays.asList(
                new Actividad("Canopy (tirolesa)", 600.0),
                new Actividad("Crucero al atardecer", 1000.0),
                new Actividad("Pesca deportiva", 1000.0),
                new Actividad("Paseo en lancha", 300.0),
                new Actividad("Show de lucha libre", 250.0),
                new Actividad("Tour en bicicleta por ciudad", 200.0)
        ));

        actividadesPorDestino.put("Los Cabos, Baja California Sur", Arrays.asList(
                new Actividad("Avistamiento de ballenas", 1200.0),
                new Actividad("Buceo en arrecifes", 1500.0),
                new Actividad("Crucero al atardecer", 1000.0),
                new Actividad("Pesca deportiva", 1000.0),
                new Actividad("Paseo en lancha", 300.0),
                new Actividad("Degustación de vinos", 500.0)
        ));

        actividadesPorDestino.put("Mazatlán, Sinaloa", Arrays.asList(
                new Actividad("Paseo en tranvía turístico", 150.0),
                new Actividad("Show de lucha libre", 250.0),
                new Actividad("Pesca deportiva", 1000.0),
                new Actividad("Caminata por senderos naturales", 50.0),
                new Actividad("Mercado artesanal", 0.0)
        ));

        actividadesPorDestino.put("Acapulco, Guerrero", Arrays.asList(
                new Actividad("Paseo en lancha", 300.0),
                new Actividad("Show nocturno de luces", 250.0),
                new Actividad("Nado con delfines", 1200.0),
                new Actividad("Cena show con danza folclórica", 500.0),
                new Actividad("Paseo nocturno de leyendas", 130.0)
        ));

        actividadesPorDestino.put("Oaxaca, Oaxaca", Arrays.asList(
                new Actividad("Clases de cocina local", 400.0),
                new Actividad("Degustación de mezcal", 350.0),
                new Actividad("Zona arqueológica (entrada general)", 85.0),
                new Actividad("Taller de cerámica", 350.0),
                new Actividad("Festival cultural", 100.0),
                new Actividad("Pueblo Mágico", 0.0)
        ));

        actividadesPorDestino.put("San Miguel de Allende, Guanajuato", Arrays.asList(
                new Actividad("Recorrido gastronómico", 600.0),
                new Actividad("Tour en bicicleta por ciudad", 200.0),
                new Actividad("Ruta de murales urbanos", 0.0),
                new Actividad("Taller de cerámica", 350.0),
                new Actividad("Museo de arte", 100.0)
        ));

        actividadesPorDestino.put("Guanajuato, Guanajuato", Arrays.asList(
                new Actividad("Paseo nocturno de leyendas", 130.0),
                new Actividad("Museo interactivo", 150.0),
                new Actividad("Ruta de murales urbanos", 0.0),
                new Actividad("Plaza histórica", 0.0),
                new Actividad("Festival cultural", 100.0)
        ));

        actividadesPorDestino.put("Puebla, Puebla", Arrays.asList(
                new Actividad("Planetario", 80.0),
                new Actividad("Museo interactivo", 150.0),
                new Actividad("Recorrido gastronómico", 600.0),
                new Actividad("Zona arqueológica (entrada general)", 85.0),
                new Actividad("Jardín botánico", 80.0)
        ));

        actividadesPorDestino.put("Monterrey, Nuevo León", Arrays.asList(
                new Actividad("Escalada en roca", 700.0),
                new Actividad("Ciclismo de montaña", 250.0),
                new Actividad("Observatorio astronómico", 250.0),
                new Actividad("Grutas y cavernas", 150.0),
                new Actividad("Paseo a caballo", 400.0)
        ));

        actividadesPorDestino.put("Mérida, Yucatán", Arrays.asList(
                new Actividad("Esnórquel en cenote", 400.0),
                new Actividad("Zona arqueológica (entrada general)", 85.0),
                new Actividad("Clases de cocina local", 400.0),
                new Actividad("Tour de café", 300.0),
                new Actividad("Pueblo Mágico", 0.0)
        ));

        actividadesPorDestino.put("Tulum, Quintana Roo", Arrays.asList(
                new Actividad("Buceo en arrecifes", 1500.0),
                new Actividad("Esnórquel en cenote", 400.0),
                new Actividad("Zona arqueológica (entrada general)", 85.0),
                new Actividad("Excursión a isla", 1000.0),
                new Actividad("Laguna bioluminiscente", 300.0)
        ));

        viajesPlaneados = new ArrayList<>();
    }

    private void initUI() {
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(240, 245, 250));

        // Panel de encabezado
        JPanel panelHeader = new JPanel(new BorderLayout());
        panelHeader.setBackground(new Color(0, 102, 153));
        panelHeader.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel lblTitulo = new JLabel("Viajes por México - Planificador de Viajes");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        panelHeader.add(lblTitulo, BorderLayout.WEST);

        JLabel lblLogo = new JLabel("✈ MÉXICO");
        lblLogo.setForeground(new Color(255, 204, 0));
        lblLogo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        panelHeader.add(lblLogo, BorderLayout.EAST);

        add(panelHeader, BorderLayout.NORTH);

        // Panel principal del formulario
        JPanel panelMain = new JPanel(new BorderLayout(10, 10));
        panelMain.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelMain.setBackground(new Color(240, 245, 250));

        JPanel panelForm = new JPanel(new GridBagLayout());
        panelForm.setBackground(Color.WHITE);
        panelForm.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 215, 230), 1),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 8, 12, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Configuración de los spinners de fecha
        spinnerFechaIda = new JSpinner(new SpinnerDateModel());
        spinnerFechaRegreso = new JSpinner(new SpinnerDateModel());

        // Formato de fecha para los spinners
        JSpinner.DateEditor editorFechaIda = new JSpinner.DateEditor(spinnerFechaIda, "dd/MM/yyyy");
        JSpinner.DateEditor editorFechaRegreso = new JSpinner.DateEditor(spinnerFechaRegreso, "dd/MM/yyyy");
        spinnerFechaIda.setEditor(editorFechaIda);
        spinnerFechaRegreso.setEditor(editorFechaRegreso);

        // Establecer fechas por defecto (hoy y 3 días después)
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1); // mañana
        spinnerFechaIda.setValue(calendar.getTime());
        calendar.add(Calendar.DAY_OF_MONTH, 2); // dos días después de mañana (total 3 desde hoy)
        spinnerFechaRegreso.setValue(calendar.getTime());

        // Configurar estilo para los componentes
        styleComponent(spinnerFechaIda);
        styleComponent(spinnerFechaRegreso);

        //Listar actividades dependiendo del destino seleccionado
        cbDestinos = new JComboBox<>(destinosDisponibles.toArray(new Destino[0]));
        styleComponent(cbDestinos);
        cbDestinos.addActionListener(e -> actualizarListaActividades());

        //Spinner para la cantidad de personas a viajar (min 1 - max 20)
        spNumPersonas = new JSpinner(new SpinnerNumberModel(1, 1, 20, 1));
        spNumPersonas.addChangeListener(e -> {
            int valor = (Integer) spNumPersonas.getValue();
            if (valor == 0) {
                JOptionPane.showMessageDialog(this, "El número de personas debe ser mayor a 0", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        });

        // Configurar estilo para el conponente
        styleComponent(spNumPersonas);

        //Campos de texto para las fechas del viaje
        tfNochesHospedaje = new JTextField(5);
        styleComponent(tfNochesHospedaje);
        tfNochesHospedaje.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                //Validar el ingreso de información
                if (!(Character.isDigit(c) || (c == KeyEvent.VK_BACK_SPACE) || (c == KeyEvent.VK_DELETE))) {
                    e.consume();
                    JOptionPane.showMessageDialog(PlanificadorTuristicoGUI.this,
                            "Solo se permiten números en este campo",
                            "Error de entrada",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        //Combo box para mostrar los tipos de hospedaje al usuario
        String[] tiposHospedaje = {"--Seleccionar tipo de hospedaje--", "Económico ($500/noche/persona)", "Turista ($900/noche/persona)",
                "Lujo ($1500/noche/persona)", "Premium ($2500/noche/persona)"};
        cbTipoHospedaje = new JComboBox<>(tiposHospedaje);
        cbTipoHospedaje.setSelectedIndex(0);

        // Configurar estilo para los componentes
        styleComponent(cbTipoHospedaje);

        // Validación de fechas
        spinnerFechaIda.addChangeListener(e -> {
            Date fechaIda = (Date) spinnerFechaIda.getValue();
            Date fechaRegreso = (Date) spinnerFechaRegreso.getValue();
            if (fechaRegreso.before(fechaIda)) {
                spinnerFechaRegreso.setValue(fechaIda);
            }
        });
        spinnerFechaRegreso.addChangeListener(e -> {
            Date fechaIda = (Date) spinnerFechaIda.getValue();
            Date fechaRegreso = (Date) spinnerFechaRegreso.getValue();
            if (fechaRegreso.before(fechaIda)) {
                JOptionPane.showMessageDialog(this,
                        "La fecha de regreso no puede ser anterior a la fecha de ida",
                        "Error de fecha",
                        JOptionPane.ERROR_MESSAGE);
                spinnerFechaRegreso.setValue(fechaIda);
            }
        });

        // Configuración de GridBagConstraints inicial
        gbc.insets = new Insets(12, 8, 12, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Fila 0: Destino y Número de personas
        gbc.gridy = 0;

        gbc.gridx = 0;
        gbc.gridwidth = 1;
        panelForm.add(createLabel("Destino:"), gbc);

        gbc.gridx = 1;
        gbc.gridwidth = 2;
        panelForm.add(cbDestinos, gbc);

        gbc.gridx = 3;
        gbc.gridwidth = 1;
        panelForm.add(createLabel("Número de personas:"), gbc);

        gbc.gridx = 4;
        panelForm.add(spNumPersonas, gbc);

        // Fila 1: Fecha de ida
        gbc.gridy = 1;

        gbc.gridx = 0;
        gbc.gridwidth = 1;
        panelForm.add(createLabel("Fecha de ida:"), gbc);

        gbc.gridx = 1;
        gbc.gridwidth = 2;
        panelForm.add(spinnerFechaIda, gbc);

        // Fila 2: Fecha de regreso
        gbc.gridy = 2;

        gbc.gridx = 0;
        gbc.gridwidth = 1;
        panelForm.add(createLabel("Fecha de regreso:"), gbc);

        gbc.gridx = 1;
        gbc.gridwidth = 2;
        panelForm.add(spinnerFechaRegreso, gbc);

        // Fila 3: Noches de hospedaje y Tipo de hospedaje
        gbc.gridy = 3;

        gbc.gridx = 0;
        gbc.gridwidth = 1;
        panelForm.add(createLabel("Noches de hospedaje:"), gbc);

        gbc.gridx = 1;
        gbc.gridwidth = 2;
        panelForm.add(tfNochesHospedaje, gbc);

        gbc.gridx = 3;
        panelForm.add(createLabel("Tipo de hospedaje:"), gbc);

        gbc.gridx = 4;
        gbc.gridwidth = 1;
        panelForm.add(cbTipoHospedaje, gbc);

        // Fila 4 y 5: Actividades disponibles y botón agregar
        gbc.gridy = 4;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        panelForm.add(createLabel("Actividades disponibles:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 3;
        gbc.gridheight = 2;
        modeloActividades = new DefaultListModel<>();
        listActividades = new JList<>(modeloActividades);
        listActividades.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        listActividades.setBackground(new Color(250, 253, 255));
        listActividades.setBorder(BorderFactory.createLineBorder(new Color(200, 215, 230)));
        JScrollPane scrollActividades = new JScrollPane(listActividades);
        scrollActividades.setPreferredSize(new Dimension(350, 180));
        panelForm.add(scrollActividades, gbc);

        gbc.gridx = 4;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        btnAgregarActividad = new JButton("Agregar >>");
        styleButton(btnAgregarActividad);
        btnAgregarActividad.addActionListener(e -> agregarActividadesSeleccionadas());
        panelForm.add(btnAgregarActividad, gbc);

        // Fila 6: Panel botones
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 5;
        gbc.gridheight = 1;
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelBotones.setOpaque(false);

        btnPlanearViaje = new JButton("Planear Viaje");
        styleButton(btnPlanearViaje, new Color(76, 175, 80)); // Verde
        btnPlanearViaje.addActionListener(e -> planearViaje());
        panelBotones.add(btnPlanearViaje);

        btnNuevoViaje = new JButton("Nuevo Viaje");
        styleButton(btnNuevoViaje, new Color(239, 83, 80)); // Rojo
        btnNuevoViaje.addActionListener(e -> nuevoViaje());
        panelBotones.add(btnNuevoViaje);

        //Agregar el Panel secundario al Panel del formulario
        panelForm.add(panelBotones, gbc);
        //Agregar el Panel de formulario al Panel principal
        panelMain.add(panelForm, BorderLayout.CENTER);
        add(panelMain, BorderLayout.CENTER);

        //Agregar la función actualizarListaActividades para que cambie conforme al destino
        actualizarListaActividades();
    }

    //Estilo para los Labels
    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 13));
        label.setForeground(new Color(70, 70, 70));
        return label;
    }

    //Estilo para los campos de información
    private void styleComponent(JComponent component) {
        component.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        component.setBackground(Color.WHITE);
        component.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 215, 230)),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
    }

    //Estilos para botones
    private void styleButton(JButton button) {
        styleButton(button, new Color(0, 102, 153));
    }
    private void styleButton(JButton button, Color color) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(color.darker()),
                BorderFactory.createEmptyBorder(8, 20, 8, 20)
        ));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.brighter());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });
    }

    //Funcion para reiniciar los campos y poder generar un nuevo viaje
    private void nuevoViaje() {
        // Campos de fecha
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1); // mañana
        spinnerFechaIda.setValue(calendar.getTime());
        calendar.add(Calendar.DAY_OF_MONTH, 2); // dos días después de mañana (total 3 desde hoy)
        spinnerFechaRegreso.setValue(calendar.getTime());

        // Campo de noches
        tfNochesHospedaje.setText("");

        //Campo de tipo de hospedaje
        cbTipoHospedaje.setSelectedIndex(0);

        //Campo de numero de personas
        spNumPersonas.setValue(1);

        // Limpiar actividades seleccionadas
        actividadesSeleccionadasGlobal.clear();

        // Actualizar lista de actividades
        actualizarListaActividades();

        // Poner foco en el primer campo (volver al destino por defecto)
        cbDestinos.requestFocus();
    }

    //Función para actualizar las actividades dependiendo del destino seleccionado
    private void actualizarListaActividades() {
        modeloActividades.clear();
        Destino destinoSeleccionado = (Destino) cbDestinos.getSelectedItem();
        if (destinoSeleccionado != null) {
            List<Actividad> actividades = actividadesPorDestino.getOrDefault(destinoSeleccionado.getNombre(), new ArrayList<>());
            for (Actividad act : actividades) {
                modeloActividades.addElement(act);
            }
        }
    }

    //Función para obtener las actividades seleccionadas por el usuario
    private void agregarActividadesSeleccionadas() {
        List<Actividad> actividadesSeleccionadas = listActividades.getSelectedValuesList();
        for (Actividad act : actividadesSeleccionadas) {
            if (!actividadesSeleccionadasGlobal.contains(act)) {
                actividadesSeleccionadasGlobal.add(act);
            }
        }
        //Mensaje de confirmación
        JOptionPane.showMessageDialog(this,
                actividadesSeleccionadas.size() + " actividad agregada con éxito.",
                "Actividades añadidas",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    //Función para validar y planear el viaje
    private void planearViaje() {
        try {
            // Validación de destino seleccionado
            if (cbDestinos.getSelectedIndex() == -1) {
                throw new Exception("Seleccione un destino");
            }

            // Obtener fechas de los spinners
            Date fechaIda = (Date) spinnerFechaIda.getValue();
            Date fechaRegreso = (Date) spinnerFechaRegreso.getValue();
            Date hoy = new Date();

            // Validar fechas
            if (fechaRegreso.before(fechaIda)) {
                throw new Exception("La fecha de regreso debe ser posterior a la fecha de ida");
            }
            if (fechaIda.before(hoy)) {
                throw new Exception("La fecha de ida no puede ser en el pasado");
            }

            // Validación de noches de hospedaje
            String nochesText = tfNochesHospedaje.getText().trim();
            if (nochesText.isEmpty()) {
                throw new Exception("Ingrese el número de noches de hospedaje");
            }
            int nochesHospedaje;
            try {
                nochesHospedaje = Integer.parseInt(nochesText);
                if (nochesHospedaje <= 0) {
                    throw new Exception("El número de noches debe ser mayor que cero");
                }
                // Calcular diferencia de días entre fechas
                long diff = fechaRegreso.getTime() - fechaIda.getTime();
                int diasViaje = (int) (diff / (1000 * 60 * 60 * 24)) + 1;

                if (nochesHospedaje > diasViaje) {
                    throw new Exception("Las noches de hospedaje no pueden superar los días entre ida y regreso");
                }
            } catch (NumberFormatException e) {
                throw new Exception("Ingrese un número válido para las noches de hospedaje");
            }

            // Validación de número de personas
            int numPersonas = (Integer) spNumPersonas.getValue();
            if (numPersonas <= 0 || numPersonas > 20) {
                throw new Exception("El número de personas debe estar entre 1 y 20");
            }

            // Validación de tipo de hospedaje
            if (cbTipoHospedaje.getSelectedIndex() == 0) {
                throw new Exception("Debe seleccionar un tipo de hospedaje");
            }
            double costoPorNochePorPersona = switch (cbTipoHospedaje.getSelectedIndex()) {
                case 1 -> 500.0;
                case 2 -> 900.0;
                case 3 -> 1500.0;
                case 4 -> 2500.0;
                default -> 0.0;
            };
            double costoHospedaje = nochesHospedaje * costoPorNochePorPersona * numPersonas;

            //Validación de actividades seleccionadas (si no selecciono ninguna actividad le da la opción de confirmar o regresar a la planeación)
            if (actividadesSeleccionadasGlobal.isEmpty()) {
                int opcion = JOptionPane.showConfirmDialog(
                        this,
                        "No has agregado actividades. ¿Deseas continuar sin actividades? El costo de actividades será $0.",
                        "Confirmar viaje sin actividades",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );
                // Permite que siga seleccionando actividades
                if (opcion != JOptionPane.YES_OPTION) {
                    return;
                }
            }

            //Obtener el destino
            Destino destino = (Destino) cbDestinos.getSelectedItem();

            //Crear nuevo viaje
            Viaje nuevoViaje = new Viaje(destino, fechaIda, fechaRegreso, costoHospedaje, numPersonas);
            for (Actividad actividad : actividadesSeleccionadasGlobal) {
                nuevoViaje.agregarActividad(actividad);
            }
            viajesPlaneados.add(nuevoViaje);
            String textoResumen = generarTextoResumen(nuevoViaje);
            JOptionPane.showMessageDialog(this, "¡Viaje a " + destino.getNombre() + " planeado con éxito!", "Éxito", JOptionPane.INFORMATION_MESSAGE);

            ResumenViajeWindow ventanaResumen = new ResumenViajeWindow(nuevoViaje, textoResumen);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        actividadesSeleccionadasGlobal.clear();
    }

    //Clase para crear el resumen del vijae que se le mostrará al usuario
    public class ResumenViajeWindow extends JFrame implements Printable {
        private Viaje viaje;

        //Ventana para mostrar el resumen aparte
        public ResumenViajeWindow(Viaje viaje, String textoResumen) {
            super("Resumen de Viaje");
            this.viaje = viaje;
            setSize(700, 750);
            setLocationRelativeTo(null);
            setLayout(new BorderLayout(10, 10));

            //Mandar llamar el resumen con formato html
            String htmlResumen = generarHTMLResumen(viaje);


            JTextPane tpResumen = new JTextPane();
            tpResumen.setContentType("text/html");
            tpResumen.setText(htmlResumen);
            tpResumen.setEditable(false);
            tpResumen.setCaretPosition(0);
            tpResumen.setBackground(new Color(250, 253, 255));
            JScrollPane scrollPane = new JScrollPane(tpResumen);
            scrollPane.setBorder(BorderFactory.createTitledBorder("Resumen del viaje"));
            add(scrollPane, BorderLayout.CENTER);
            JButton btnImprimir = new JButton("Guardar como PDF");
            btnImprimir.setFont(new Font("Segoe UI", Font.BOLD, 14));
            btnImprimir.addActionListener(e -> exportarResumenComoPDF(generarHTMLResumen(viaje)));
            JPanel pnlBoton = new JPanel();
            pnlBoton.add(btnImprimir);
            add(pnlBoton, BorderLayout.SOUTH);
            setVisible(true);
        }

        //Función para generar el resumen de viaje para el usuario
        private String generarHTMLResumen(Viaje viaje) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

            double subtotalTrans = viaje.getDestino().getCostoTransporte() * viaje.getNumPersonas();
            double subtotalAct = viaje.getActividades().stream()
                    .mapToDouble(Actividad::getCosto).sum();

            StringBuilder sb = new StringBuilder();
            sb.append("<html><body style='font-family:sans-serif; color:#333;'>");
            sb.append("<h2 style='color:#0059ab;'>Resumen del Viaje</h2>");

            sb.append("<p><strong>Destino:</strong> ").append(viaje.getDestino().getNombre()).append("</p>");
            sb.append("<p><strong>Fechas:</strong> ").append(sdf.format(viaje.getFechaIda()))
                    .append(" al ").append(sdf.format(viaje.getFechaRegreso())).append("</p>");
            sb.append("<p><strong>Duración:</strong> ").append(viaje.getDuracion()).append(" días</p>");
            sb.append("<p><strong>No. de Personas:</strong> ").append(viaje.getNumPersonas()).append("</p>");

            sb.append("<h3 style='color:#5db2e1;'>Detalle de Costos</h3>");
            sb.append("<ul>");
            sb.append(String.format("<li><strong>Transporte:</strong> $%,.2f (x%d personas)</li>",
                    viaje.getDestino().getCostoTransporte(), viaje.getNumPersonas()));
            sb.append(String.format("<li><strong>Hospedaje:</strong> $%,.2f</li>",
                    viaje.getCostoHospedaje()));
            sb.append("</ul>");

            sb.append("<h3 style='color:#5db2e1;'>Actividades Incluidas</h3>");
            sb.append("<ul>");
            for (Actividad actividad : viaje.getActividades()) {
                sb.append(String.format("<li>%s - $%,.2f</li>",
                        actividad.getNombre(), actividad.getCosto()));
            }
            sb.append("</ul>");

            sb.append("<h3 style='color:#8358c8;'>Resumen Final</h3>");
            sb.append("<p><strong>Subtotal Transporte:</strong> $").append(String.format("%,.2f", subtotalTrans)).append("</p>");
            sb.append("<p><strong>Subtotal Hospedaje:</strong> $").append(String.format("%,.2f", viaje.getCostoHospedaje())).append("</p>");
            sb.append("<p><strong>Subtotal Actividades:</strong> $").append(String.format("%,.2f", subtotalAct)).append("</p>");
            sb.append("<hr>");
            sb.append("<h2 style='color:#ef3c24;'>Total del Viaje: $").append(String.format("%,.2f", viaje.calcularCostoTotal())).append(" MXN</h2>");

            sb.append("</body></html>");
            return sb.toString();
        }

        //Función para exportar el resumen a pdf
        private void exportarResumenComoPDF(String htmlResumen) {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Guardar resumen como PDF");
            fileChooser.setSelectedFile(new File("ResumenViaje.pdf"));

            int userSelection = fileChooser.showSaveDialog(this);
            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();

                try {
                    com.lowagie.text.Document document = new com.lowagie.text.Document();
                    com.lowagie.text.pdf.PdfWriter writer = com.lowagie.text.pdf.PdfWriter.getInstance(document, new FileOutputStream(fileToSave));
                    document.open();

                    // Convertir HTML a elementos PDF simples (sin CSS complejo)
                    com.lowagie.text.html.simpleparser.HTMLWorker htmlWorker = new com.lowagie.text.html.simpleparser.HTMLWorker(document);
                    htmlWorker.parse(new StringReader(htmlResumen));

                    document.close();

                    JOptionPane.showMessageDialog(this, "Resumen exportado como PDF exitosamente.",
                            "Éxito", JOptionPane.INFORMATION_MESSAGE);

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this,
                            "Error al guardar PDF: " + ex.getMessage(),
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }

        @Override
        public int print(Graphics g, PageFormat pf, int pageIndex) throws PrinterException {
            if (pageIndex > 0) return NO_SUCH_PAGE;
            Graphics2D g2d = (Graphics2D) g;
            g2d.translate(pf.getImageableX(), pf.getImageableY());
            return PAGE_EXISTS;
        }
    }

    //Texto para el resumen
    private String generarTextoResumen(Viaje viaje) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        StringBuilder sb = new StringBuilder();
        sb.append("══════════════════════════════════════════════════\n");
        sb.append("           RESUMEN DE VIAJE            \n");
        sb.append("══════════════════════════════════════════════════\n\n");
        sb.append("Destino: ").append(viaje.getDestino().getNombre()).append("\n");
        sb.append("Fechas: ").append(sdf.format(viaje.getFechaIda())).append(" al ")
                .append(sdf.format(viaje.getFechaRegreso())).append("\n");
        sb.append("Duración: ").append(viaje.getDuracion()).append(" días\n");
        sb.append("Personas: ").append(viaje.getNumPersonas()).append("\n\n");

        sb.append("DETALLE DE COSTOS (MXN):\n");
        sb.append(String.format(" - Transporte: $%,.2f (x%d personas)%n",
                viaje.getDestino().getCostoTransporte(), viaje.getNumPersonas()));
        sb.append(String.format(" - Hospedaje:   $%,.2f%n", viaje.getCostoHospedaje()));
        sb.append("\nACTIVIDADES INCLUIDAS:\n");
        for (Actividad actividad : viaje.getActividades()) {
            sb.append(String.format(" - %-25s $%,.2f%n",
                    actividad.getNombre(), actividad.getCosto()));
        }

        double subtotalTrans = viaje.getDestino().getCostoTransporte() * viaje.getNumPersonas();
        double subtotalAct = viaje.getActividades().stream()
                .mapToDouble(Actividad::getCosto).sum();

        sb.append("\nSUBTOTALES:\n");
        sb.append(String.format(" - Transporte: $%,.2f%n", subtotalTrans));
        sb.append(String.format(" - Hospedaje:  $%,.2f%n", viaje.getCostoHospedaje()));
        sb.append(String.format(" - Actividades:$%,.2f%n", subtotalAct));
        sb.append("----------------------------------------------\n");
        sb.append(String.format("TOTAL DEL VIAJE: $%,.2f MXN%n", viaje.calcularCostoTotal()));
        sb.append("══════════════════════════════════════════════════\n");

        return sb.toString();
    }

    //Clase para obtener los datos ingresados en el formulario del viaje
    class Viaje {
        private Destino destino;
        private Date fechaIda;
        private Date fechaRegreso;
        private double costoHospedaje;
        private int numPersonas;
        private List<Actividad> actividades;

        public Viaje(Destino destino, Date fechaIda, Date fechaRegreso, double costoHospedaje, int numPersonas) {
            this.destino = destino;
            this.fechaIda = fechaIda;
            this.fechaRegreso = fechaRegreso;
            this.costoHospedaje = costoHospedaje;
            this.numPersonas = numPersonas;
            this.actividades = new ArrayList<>();
        }

        public void agregarActividad(Actividad actividad) {
            actividades.add(actividad);
        }

        public int getDuracion() {
            long diff = fechaRegreso.getTime() - fechaIda.getTime();
            return (int) (diff / (1000 * 60 * 60 * 24)) + 1;
        }

        public double calcularCostoTotal() {
            double total = (destino.getCostoTransporte() * numPersonas) + costoHospedaje;
            for (Actividad actividad : actividades) {
                total += actividad.getCosto();
            }
            return total;
        }

        public Destino getDestino() {
            return destino;
        }

        public Date getFechaIda() {
            return fechaIda;
        }

        public Date getFechaRegreso() {
            return fechaRegreso;
        }

        public double getCostoHospedaje() {
            return costoHospedaje;
        }

        public int getNumPersonas() {
            return numPersonas;
        }

        public List<Actividad> getActividades() {
            return new ArrayList<>(actividades);
        }
    }

    //Clase para obtener los datos del destino seleccionado por el usuario
    class Destino {
        private String nombre;
        private double costoTransporte;

        public Destino(String nombre, double costoTransporte) {
            this.nombre = nombre;
            this.costoTransporte = costoTransporte;
        }

        @Override
        public String toString() {
            return nombre + " ($" + String.format("%,.2f", costoTransporte) + " MXN)";
        }

        public String getNombre() {
            return nombre;
        }

        public double getCostoTransporte() {
            return costoTransporte;
        }
    }

    //Clase para obtener las actividades seleccionadas por el usuario
    class Actividad {
        private String nombre;
        private double costo;

        public Actividad(String nombre, double costo) {
            this.nombre = nombre;
            this.costo = costo;
        }

        @Override
        public String toString() {
            return nombre + " ($" + String.format("%,.2f", costo) + " MXN)";
        }

        public String getNombre() {
            return nombre;
        }

        public double getCosto() {
            return costo;
        }
    }
}